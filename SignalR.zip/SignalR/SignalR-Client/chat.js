"use strict";

const connection = new signalR.HubConnectionBuilder()
    .withUrl("https://localhost:7060/chathub")
    .configureLogging(signalR.LogLevel.Information)
    .build();

const start = async () => {
    try {
        await connection.start();
        console.log("Connected to SignalR hub");
    } catch (error) {
        console.log(error);
    }
}

// получаем имя пользователя из модального окна и сохраняем его в хранилище сеанса
// хранилище сеанса существует до тех пор, пока не будет открыта вкладка браузера
const joinUser = async () => {
    const name = window.prompt('Enter the name: ');
    if (name) {
        sessionStorage.setItem('user', name);   
        await joinChat(name);
    }
}

const joinChat = async (user) => {
    if (!user)
       return;
    try {
        const message = `${user} joined`;
        await connection.invoke("JoinChat", user, message);
    } catch (error) {
        console.log(error);
    }
}

// извлекаем пользователя из хранилища сессии
const getUser = () => sessionStorage.getItem('user');

// метод получения уведомления от сервера
const receiveMessage = async () => {
    const currentUser = getUser();
    if (!currentUser)
        return;
    try {
        connection.on("ReceiveMessage", (user, message) => {
            const messageClass = currentUser === user ? "sender" : "received";
            appendMessage(message, messageClass);
        })
    } catch (error) {
        console.log(error);
    }
}

const appendMessage = (message, messageClass) => {
    const messageSectionEl = document.getElementById('messageBox');
    const msgBoxEl = document.createElement("div");
    msgBoxEl.classList.add("msg");
    msgBoxEl.classList.add(messageClass);
    msgBoxEl.innerHTML = message;
    messageSectionEl.appendChild(msgBoxEl);
}

// привязываем событие для кнопки отправки
document.getElementById('btnSend').addEventListener('click', async (e) => {
    e.preventDefault();
    const user = getUser();
    if (!user)
        return;
    const txtMessageEl = document.getElementById('txtMessage');
    const msg = txtMessageEl.value;
    if (msg) {
        await sendMessage(user,`${user}: ${msg}`);  
        txtMessageEl.value = "";
    }
})

const sendMessage = async (user,message) => {
    try {
        await connection.invoke('SendMessage', user, message);
    } catch (error) {
        console.log(error);
    }
}

const startApp = async () => {
    await start();
    await joinUser();
    await receiveMessage();
}

startApp();